#ifndef _SYSAL_TYPEDEF_VECTORS_
#define _SYSAL_TYPEDEF_VECTORS_

#pragma pack(push)
#pragma pack(4)

typedef struct 
{
	float X;
	float Y;
	float Z;
	} TVector;

#pragma pack(pop)

#endif


