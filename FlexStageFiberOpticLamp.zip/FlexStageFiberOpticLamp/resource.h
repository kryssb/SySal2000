//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by FlexStage.rc
//
#define IDS_PROJNAME                    100
#define IDR_FLEXSTAGE                   102
#define IDD_MONITOR                     201
#define IDC_M_XPOS                      201
#define IDC_M_YPOS                      202
#define IDI_ICON64                      202
#define IDC_M_ZPOS                      203
#define IDI_ICON32                      203
#define IDC_M_XRED                      204
#define IDD_EDIT_CONFIG                 204
#define IDC_M_XGREEN                    205
#define IDC_M_YRED                      206
#define IDC_M_YGREEN                    207
#define IDC_M_ZRED                      208
#define IDC_M_ZGREEN                    209
#define IDC_M_HIDE                      210
#define IDC_M_TOGGLEMANUAL              211
#define IDC_M_RESET                     212
#define IDC_M_XYSPEED                   213
#define IDC_M_ZSPEED                    214
#define IDC_M_LIGHT                     215
#define IDC_M_LIGHTLEVEL                216
#define IDC_M_10                        217
#define IDC_EC_BOARDID                  217
#define IDC_M_1                         218
#define IDC_EC_ACCELFACT                218
#define IDC_EC_INVLIMPOL                219
#define IDC_EC_CONSTSPEEDACCEL          220
#define IDC_EC_XY_ACCEL                 221
#define IDC_EC_XY_ENC2MICRON            222
#define IDC_EC_XY_LINESREV              223
#define IDC_EC_XY_STEPSREV              224
#define IDC_EC_XY_MANMAXSPEED           225
#define IDC_EC_XY_MANSPEEDMULT          226
#define IDC_EC_XY_MAXSPEED              227
#define IDC_EC_XY_MANMAXSPEEDCHANGE     228
#define IDC_EC_Z_ENC2MICRON             229
#define IDC_EC_Z_STEPSREV               230
#define IDC_EC_Z_LINESREV               231
#define IDC_EC_Z_ACCEL                  232
#define IDC_EC_Z_MAXSPEED               233
#define IDC_EC_Z_MANSPEEDMULT           234
#define IDC_EC_Z_MANMAXSPEED            235
#define IDC_EC_Z_MANMAXSPEEDCHANGE      236
#define IDC_EC_STEPDIR                  237
#define IDC_EC_CWCCW                    238
#define IDC_EC_LIGHTLIMIT               239
#define IDC_EC_INVERTX                  240
#define IDC_EC_INVERTY                  241
#define IDC_EC_INVERTZ                  242

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        205
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         241
#define _APS_NEXT_SYMED_VALUE           103
#endif
#endif
