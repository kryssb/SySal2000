//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by FlexMap3.rc
//
#define IDS_PROJNAME                    100
#define IDR_FLEXIBLEMAP                 102
#define IDI_ICON64                      201
#define IDC_EC_GRAYTHRESHOLD            201
#define IDC_EC_CLUSTERPARAM             201
#define IDI_ICON32                      202
#define IDC_EC_THRESHOLDS               202
#define IDC_EC_FRAMESPERSECOND          202
#define IDD_EDIT_CONFIG                 203
#define IDC_EC_THRESHOLDSTEP            203
#define IDC_EC_DIAMETER                 204
#define IDD_INIT_MAP                    204
#define IDC_EC_DIAMETERTOL              205
#define IDD_REUSE_POLICY                205
#define IDC_EC_ELLIPTICITY              206
#define IDC_EC_FOCUSSPEED               207
#define IDC_EC_FOCUSSTROKE              208
#define IDC_EC_MAXCLUSTERS              209
#define IDC_EC_HORZTOL                  210
#define IDC_EC_VERTTOL                  211
#define IDC_EC_TIMEOUT                  212
#define IDC_EC_LONGDISTSPEED            213
#define IDC_EC_LONGDISTACC              214
#define IDC_EC_SHORTDISTSPEED           215
#define IDC_EC_SHORTDISTACC             216
#define IDC_EC_FIELDMAPFILE             217
#define IDC_EC_SHEETROTATEDBY180        218
#define IDC_EC_RECOVERYFILE             219
#define IDC_IM_TOTALMARKS               219
#define IDC_EC_CENTERTOL                220
#define IDC_IM_MARKSSCANNED             220
#define IDC_IM_BADMARKS                 221
#define IDC_EC_VERTACC                  221
#define IDC_IM_GRIDVIEW                 222
#define IDC_EC_ZSETSPEED                222
#define IDC_IM_ID                       223
#define IDC_EC_TOTALTHICKNESS           223
#define IDC_IM_NUMBER                   224
#define IDC_IM_STATUS                   225
#define IDC_IM_NOMX                     226
#define IDC_IM_NOMY                     227
#define IDC_IM_STAGEX                   228
#define IDC_IM_STAGEY                   229
#define IDC_IM_STAGEZ                   230
#define IDC_IM_MARKVIEW                 231
#define IDC_IM_PREV                     232
#define IDC_IM_NEXT                     233
#define IDC_EC_SELFIELDMAPFILE          233
#define IDC_IM_SETXY                    234
#define IDC_EC_SELRECOVERYFILE          234
#define IDC_RP_NOREUSE                  234
#define IDC_IM_SETZ                     235
#define IDC_RP_REINTERPRET              235
#define IDC_EC_SEARCHFIRSTMARK          235
#define IDC_IM_PAUSE                    236
#define IDC_RP_REPOSITION               236
#define IDC_IM_CONTINUE                 237
#define IDC_RP_LOAD                     237
#define IDC_IM_ABORT                    238
#define IDC_RP_REINTERPRETLOAD          238
#define IDC_IM_SKIP                     239
#define IDC_IM_RESCAN                   240

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        206
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         236
#define _APS_NEXT_SYMED_VALUE           103
#endif
#endif
