#ifndef _SYSAL_LYONTRACKER_CONFIGDATA_H_
#define _SYSAL_LYONTRACKER_CONFIGDATA_H_

struct ConfigData
{
	/* IMAD: put here all parameters */
	float Sample_Float;
	int Sample_Int;
	};

#endif