//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by LyonTracker.rc
//
#define IDC_EC_HELP                     4
#define IDS_PROJNAME                    100
#define IDR_LYONTRACKER                 102
#define IDI_ICON32                      201
#define IDI_ICON64                      202
#define IDD_EDIT_CONFIG                 203
#define IDC_EC_SAMPLEFLOAT              222
#define IDC_EC_SAMPLEINT                223

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        206
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         223
#define _APS_NEXT_SYMED_VALUE           103
#endif
#endif
