//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by ScanServer.rc
//
#define IDR_MANIFEST                    1
#define IDCANCEL2                       3
#define IDC_MAIN_TEST                   3
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_SCANSERVER_DIALOG           102
#define IDR_SCANSERVER                  103
#define IDR_COMSCANSERVER               104
#define IDR_ZOZ                         105
#define IDR_MAINFRAME                   128
#define IDI_ICON64                      131
#define IDI_ICON32                      132
#define IDB_BANNER                      133
#define IDC_MAIN_LOGBOX                 1001
#define IDC_RICHEDIT21                  1002

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           106
#endif
#endif
