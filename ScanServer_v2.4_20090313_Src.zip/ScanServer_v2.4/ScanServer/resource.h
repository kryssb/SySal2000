//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by ScanServer.rc
//
#define IDR_MANIFEST                    1
#define IDC_TEST                        3
#define IDC_TEST2                       4
#define IDC_SHOWMONITORS                4
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_COMTEST_DIALOG              102
#define IDD_SCANSERVER_DIALOG           102
#define IDR_MAINFRAME                   128
#define IDD_TESTMODE                    129
#define IDB_BANNER                      133
#define IDC_MAIN_LOGBOX                 1001
#define IDC_CLOSE                       1002
#define IDC_TB_LOADPLATE                1003
#define IDC_TB_LOADPLATE_BRICK          1004
#define IDC_TB_LOADPLATE_PLATE          1005
#define IDC_TB_LOADPLATE_TEXTDESC       1006
#define IDC_TB_LOADPLATE_MAPINIT        1007
#define IDC_TB_UNLOADPLATE              1008
#define IDC_TB_SCAN                     1009
#define IDC_TB_SCAN_ZONEID              1010
#define IDC_TB_SCAN_MINX                1011
#define IDC_TB_SCAN_MAXX                1012
#define IDC_TB_SCAN_MINY                1013
#define IDC_TB_SCAN_MAXY                1014
#define IDC_TB_SCAN_PRESETSLOPE         1015
#define IDC_TB_SCAN_SLOPEX              1016
#define IDC_TB_SCAN_SLOPEY              1017
#define IDC_TB_SCAN_SLOPEXACC           1018
#define IDC_TB_SCAN_SLOPEYACC           1019
#define IDC_TB_SCAN_MOVENEXT            1020
#define IDC_TB_DONE                     1021
#define ID_TB_HIDE                      1022
#define IDC_TB_SCAN_NEXTMINX            1023
#define IDC_TB_SCAN_NEXTMAXX            1024
#define IDC_TB_SCAN_NEXTMINY            1025
#define IDC_TB_SCAN_NEXTMAXY            1026
#define IDC_TB_SETSINGLEPARAM           1027
#define IDC_TB_SETSINGLEPARAM_OBJECT    1028
#define IDC_TB_SETSINGLEPARAM_PARAM     1029
#define IDC_TB_SETSINGLEPARAM_VALUE     1030
#define IDC_TB_SETOBJCONFIG             1031
#define IDC_TB_SETOBJCONFIG_OBJECT      1032
#define IDC_TB_SETOBJCONFIG_CONFIG      1033
#define IDC_TB_SETSCANLAYOUT            1034
#define IDC_TB_SETSCANLAYOUT_LAYOUT     1035
#define IDC_TB_MANUALCHECK              1036
#define IDC_TB_MANUALCHECK_ID           1037
#define IDC_TB_MANUALCHECK_POSX         1038
#define IDC_TB_MANUALCHECK_POSY         1039
#define IDC_TB_MANUALCHECK_SLOPEX       1040
#define IDC_TB_MANUALCHECK_SLOPEY       1041
#define IDC_TB_MANUALCHECK_POSTOL       1042
#define IDC_TB_MANUALCHECK_SLOPETOL     1043
#define IDC_TB_LOADPLATE_TEXTDESC2      1044
#define IDC_TB_LOADPLATE_OUTNAME        1044
#define IDC_TB_MANUALCHECK_GRAINS       1045
#define IDC_TB_MANUALCHECK_FOUNDX       1046
#define IDC_TB_MANUALCHECK_FOUNDY       1047
#define IDC_TB_MANUALCHECK_FOUNDSX      1048
#define IDC_TB_MANUALCHECK_FOUNDSY      1049
#define IDC_TB_GETFOGTHICKNESS          1050
#define IDC_TB_GETFOGTHICK_TOPFOG       1051
#define IDC_TB_GETFOGTHICK_BOTFOG       1052
#define IDC_TB_GETFOGTHICK_TOPTHK       1053
#define IDC_TB_GETFOGTHICK_BOTTHK       1054
#define IDC_TB_GETFOGTHICK_BASETHK      1055
#define IDC_TB_CHECKDONE                1056
#define ID_TB_SEND                      1057
#define IDC_TB_EXCEPTION                1058
#define IDC_TB_CHECKDONE2               1059
#define IDC_TB_FOUND                    1059

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1023
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
