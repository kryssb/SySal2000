//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SmartTracker7.rc
//
#define IDC_EC_TEST                     3
#define IDC_TS_LOAD                     3
#define IDC_TS_SELFILE                  4
#define IDC_EC_HELP                     4
#define IDC_TS_TEST                     5
#define IDC_TS_HELP                     6
#define IDC_TS_PROCESS                  7
#define IDC_TS_SELOUTFILE               8
#define IDS_PROJNAME                    100
#define IDR_SMARTTRACKER                102
#define IDI_ICON32                      201
#define IDC_EC_MAXGRAINS                201
#define IDI_ICON64                      202
#define IDC_EC_MAXLAYERS                202
#define IDD_EDIT_CONFIG                 203
#define IDC_EC_CELLSX                   203
#define IDC_EC_CELLSY                   204
#define IDC_EC_CELLOVERFLOW             205
#define IDD_TEST                        205
#define IDC_EC_MINPIXELS                206
#define IDC_EC_MAXPIXELS                207
#define IDC_EC_TOPLAYER                 208
#define IDC_EC_BOTTOMLAYER              209
#define IDC_EC_TRIGGERCOUNT             210
#define IDC_EC_DHARD                    211
#define IDC_EC_ALIGNTOL                 211
#define IDC_EC_REPLICARADIUS            212
#define IDC_EC_MINSLOPE                 213
#define IDC_EC_MAXSLOPE                 214
#define IDC_EC_REPLICASAMPLEDIVIDER     215
#define IDC_EC_MINPOINTS0               216
#define IDC_EC_MINGRAINS                216
#define IDC_EC_NPTMINV                  216
#define IDC_EC_TRIALLIST                217
#define IDC_EC_ADD                      218
#define IDC_EC_DEL                      219
#define IDC_TS_DATAFILE                 219
#define IDC_EC_NPTMINH                  220
#define IDC_TS_CYCLES                   220
#define IDC_EC_NPTMIN01                 221
#define IDC_TS_MAXTRACKS                221
#define IDC_EC_PROCESSORS               222
#define IDC_TS_TIME                     222
#define IDC_TS_TRACKSFOUND              223
#define IDC_EC_MINREPLICAS              223
#define IDC_EC_MAXREPLICASPREAD         224
#define IDC_TS_OUTFILE                  224
#define IDC_EC_MAXTRACKINGTIME          225
#define IDC_EC_DISCARDSHADOWSIGMA       226
#define IDC_EC_CHECKGRAINSPACING        227

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        206
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         228
#define _APS_NEXT_SYMED_VALUE           103
#endif
#endif
