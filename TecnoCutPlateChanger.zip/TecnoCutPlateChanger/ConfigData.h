#ifndef _CONFIGDATA_H_
#define _CONFIGDATA_H_



struct ConfigData
{
	int CHANGEME;
	float CHANGEME2;
	};


#endif