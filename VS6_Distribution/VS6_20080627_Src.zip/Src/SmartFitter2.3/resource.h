//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SmartFitter.rc
//
#define IDOK2                           3
#define IDS_PROJNAME                    100
#define IDR_SMARTFITTER                 102
#define IDI_ICON64                      201
#define IDC_EC_KEEPALL                  201
#define IDI_ICON32                      202
#define IDC_EC_DISCARDONCE              202
#define IDD_EDIT_CONFIG                 203
#define IDC_EC_ITERATEDISCARDING        203
#define IDC_EC_MINPOINTS                204
#define IDC_EC_MAXSIGMA                 205
#define IDC_EC_MAXPOINTDELTA            206
#define IDC_EC_GOODPOINTS               207
#define IDC_EC_ENABLEPARABOLICCORRECTION 208
#define IDC_EC_MAXDISTX                 209
#define IDC_EC_MAXDISTY                 210
#define IDC_EC_MAXITERATIONS            211
#define IDC_EC_DISTWINDOWX              212
#define IDC_EC_DISTWINDOWY              213
#define IDC_EC_ENABLERECOVERY           214
#define IDC_EC_DELTAPOS                 215
#define IDC_EC_DELTASLOPE               216
#define IDC_EC_EXCLUSIONDISTANCE        217
#define IDC_EC_MAXMEM                   217

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        204
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         215
#define _APS_NEXT_SYMED_VALUE           103
#endif
#endif
