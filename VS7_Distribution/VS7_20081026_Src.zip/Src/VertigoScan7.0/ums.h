#ifndef _USER_MESSAGES_
#define _USER_MESSAGES_

#define UM_CHANGE_STATUS			(WM_APP + 0x300)
#define UM_STOP						(WM_APP + 0x800)
#define UM_END						(WM_APP + 0x801)
#define UM_ERROR					(WM_APP + 0x802)
#define UM_RCS_CONNECT_DISCONNECT	(WM_APP + 0x810)

#endif