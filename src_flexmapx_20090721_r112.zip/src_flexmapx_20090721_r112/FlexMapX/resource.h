//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by FlexMapX.rc
//
#define IDS_PROJNAME                    100
#define IDR_FLEXIBLEMAP                 101
#define IDI_ICON32                      151
#define IDI_ICON64                      152
#define IDD_EDIT_CONFIG                 201
#define IDD_INIT_MAP                    202
#define IDD_MAIN                        203
#define IDD_MAPMONITOR                  204
#define IDC_EC_BINSIZE                  210
#define IDC_EC_CENTERTOL                211
#define IDC_EC_DIAMETER                 212
#define IDC_EC_DIAMETERTOL              213
#define IDC_EC_ECCENTRICITY             214
#define IDC_EC_FIRSTRING                215
#define IDC_EC_FOCUSSPEED               216
#define IDC_EC_FOCUSPATHLENGTH          217
#define IDC_EC_FORCELATERALMARKFINDING  218
#define IDC_EC_FRAMERATE                219
#define IDC_EC_GREYSAMPLE               220
#define IDC_EC_HORZTOL                  221
#define IDC_EC_LONGDISTACC              222
#define IDC_EC_LONGDISTSPEED            223
#define IDC_EC_MAXCLUSTERS              224
#define IDC_EC_MAXSTRIPCANDIDATES       225
#define IDC_EC_PEAKTHRESHOLD            226
#define IDC_EC_RECOVERYFILE             227
#define IDC_EC_SCANTRANSVTOL            228
#define IDC_EC_SEARCHFIRSTMARK          229
#define IDC_EC_SELRECOVERYFILE          230
#define IDC_EC_SETTLINGTIME             231
#define IDC_EC_SHEETROTATEDBY180        232
#define IDC_EC_SHORTDISTSPEED           233
#define IDC_EC_SHORTDISTACC             234
#define IDC_EC_STRIPSAMPLINGDISTANCE    235
#define IDC_EC_STRIPWIDTH               236
#define IDC_EC_TIMEOUT                  237
#define IDC_EC_TOTALTHICKNESS           238
#define IDC_EC_VERTACC                  239
#define IDC_EC_VERTTOL                  240
#define IDC_EC_VPPROGRAM                241
#define IDC_EC_ZSETSPEED                242
#define IDC_EC_PAUSENOTFOUNDCLONE       243
#define IDC_IM_PAUSE                    260
#define IDC_IM_NEXTMARKID               261
#define IDC_IM_NEXTMARKTYPE             262
#define IDC_IM_MAPPEDX                  263
#define IDC_IM_MAPPEDY                  264
#define IDC_IM_NEXTMARKSIDE             265
#define IDC_IM_NEXTMARKSTATUS           266
#define IDC_IM_STATICX                  267
#define IDC_IM_STATICY                  268
#define IDC_IM_SETZ                     269
#define IDC_IM_ACTION                   270
#define IDC_IM_SETFOUND                 271
#define IDC_IM_SETY                     272
#define IDC_IM_EXIT                     273
#define IDC_IM_STAGEX                   274
#define IDC_IM_STAGEY                   275
#define IDC_IM_PREV                     276
#define IDC_IM_NEXT                     277
#define IDC_IM_SETX                     278
#define IDC_MN_IMGVSCROLL               301
#define IDC_MN_HIDE                     302
#define IDC_MN_BTN_SAVEIMAGE            303
#define IDC_MN_BEST_TRANSFORM           304
#define IDC_MN_REPORT                   305
#define IDC_MN_X                        306
#define IDC_MN_Y                        307
#define IDC_MN_BTN_SAVEMAP              308
#define IDC_MAIN_SELPATH                330
#define IDC_MAIN_RADIO1                 331
#define IDC_MAIN_RADIO2                 332
#define IDC_MAIN_RADIO0                 333
#define IDC_MAIN_RADIO4                 334
#define IDC_MAIN_RADIO3                 335
#define IDC_MAIN_INITSTRING             336
#define IDC_MAIN_SEARCHFIRSTMARK        337
#define IDC_MAIN_SHEETROTATEDBY180      338
#define IDC_MAIN_FORCELATERAL           339
#define IDC_MAIN_EDITCONFIG             340
#define IDC_MAIN_RADIO5                 341
#define IDC_BUTTON1                     1026
#define IDC_EDIT1                       1027
#define IDC_EDIT2                       1028
#define IDC_BUTTON2                     1029
#define IDC_SCROLLBAR2                  1031
#define IDC_MN_IMGHSCROLL               1031
#define IDC_MN_IMAGE                    1032
#define IDC_MN_SCROLLBAR_HOR            1033
#define IDC_SCROLLBAR3                  1034
#define IDC_MN_SCROLLBAR_VER            1034
#define IDC_MN_IMAGE2                   1035
#define IDC_MN_IMGPANEL                 1035

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        105
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1035
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
