// CDlgMapLibrary.cpp : implementation file
//

#include "stdafx.h"
#include "MapBuilder.h"
#include "DlgMapLibrary.h"


// CDlgMapLibrary dialog

IMPLEMENT_DYNAMIC(CDlgMapLibrary, CDialog)

CDlgMapLibrary::CDlgMapLibrary(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgMapLibrary::IDD, pParent)
{

}

CDlgMapLibrary::~CDlgMapLibrary()
{
}

void CDlgMapLibrary::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


// CDlgMapLibrary message handlers

BOOL CDlgMapLibrary::OnInitDialog()
{
	CDialog::OnInitDialog();
	
   // TODO: Add extra initialization here
   GetDlgItem( IDC_EDIT_TM1 )->SetWindowText ( _T("mapext: 0 0 0 0; 4 0.0 0.0 125000.0 99800.0; 1   22427.1 13044.5   25968.6 17694.0 1 1 2 ; 2   22039.4 83527.5   25819.3 88187.7 1 1 2 ; 3 107442.0 63837.1 111091.1 68211.8 1 1 2 ; 4 107663.6 13493.5 111199.0 17828.5 1 1 2") );
   GetDlgItem( IDC_EDIT_TM2 )->SetWindowText ( _T("corners: 0 0 0 0; 4 0.0 0.0 125000.0 99800.0; 1        0.0            0.0     3714.7     4722.2 1 1 1 ; 2        0.0    99800.0     3668.0 104346.7 1 1 1 ; 3 125000.0 99800.0 128697.9 104308.4 1 1 1 ; 4 125000.0         0.0 128739.6     4696.7 1 1 1") ) ;
   GetDlgItem( IDC_EDIT_TM3 )->SetWindowText ( _T("mapext: 0 0 0 0; 6 0.0 0.0 125000.0 99800.0; 1     9645.0 10256.0   13500.8 14987.8 1 1 2 ;   2     9457.0 90648.0   13470.3 95391.8 1 1 2 ;   3   44715.0 90764.0   48725.2 95429.2 1 1 2 ;   4 114838.0 90930.0 118826.4 95455.0 1 1 2 ;  5 115069.0 10483.0 118910.8 14996.6 1 1 2 ; 6   62409.0 10427.0   66261.0 15043.9 1 1 2") );
   GetDlgItem( IDC_EDIT_TM4 )->SetWindowText ( _T("mapext: 0 0 0 0; 4 0.0 0.0 125000.0 99800.0; 1     9645.0 10256.0   13500.8 14987.8 1 1 2 ;   2     9457.0 90648.0   13470.3 95391.8 1 1 2 ;   4 114838.0 90930.0 118826.4 95455.0 1 1 2 ;  5 115069.0 10483.0 118910.8 14996.6 1 1 2") );
   GetDlgItem( IDC_EDIT_TM5 )->SetWindowText ( _T("mapX: 0 0 0 0; 2 0.0 0.0 125000.0 99800.0;     1 121675.0   2399.0 125581.5    7490.2  1 1 2 ; 2 121388.0 97203.0 124765.4 102398.6 1 1 2") ) ;
   GetDlgItem( IDC_EDIT_TM6 )->SetWindowText ( _T("mapX: 0 0 0 0; 2 0.0 0.0 125000.0 99800.0;     1   3278.0   2507.0   3278.0    2507.0  1 1 1 ;   2   3546.0 97132.0   3546.0  97132.0 1 1 1") ) ;
	
   //GetDlgItem( IDC_EDIT_TM6 )->SetWindowText ( _T("corners: 0 0 0 0; 4 0.0 0.0 125000.0 99800.0; 1        0.0            0.0     3714.7     4722.2 1 1 1 ; 3 125000.0 99800.0 128697.9 104308.4 1 1 1") ) ;
   
   return TRUE;  // return TRUE  unless you set the focus to a control
}

