#pragma once


// CDlgMapLibrary dialog

class CDlgMapLibrary : public CDialog
{
	DECLARE_DYNAMIC(CDlgMapLibrary)

public:
	CDlgMapLibrary(CWnd* pParent = NULL);   // standard constructor
	virtual ~CDlgMapLibrary();

// Dialog Data
	enum { IDD = IDD_MAPLIBRARY_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

   // Generated message map functions
   virtual BOOL OnInitDialog();

};
