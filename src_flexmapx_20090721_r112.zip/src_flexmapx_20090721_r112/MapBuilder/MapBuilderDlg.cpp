// MapBuilderDlg.cpp : implementation file
//

#include "cstringt.h"
#include "stdafx.h"
#include "MapBuilder.h"
#include "MapBuilderDlg.h"
#include "DlgMapLibrary.h"

#include <iostream>
#include <fstream>
#include <string>

#include "../ESS/MarkMapBuilder.h"

using namespace ESS::Scanning ;

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


// CMapBuilderDlg dialog




CMapBuilderDlg::CMapBuilderDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMapBuilderDlg::IDD, pParent)
   , m_strOutputMap(_T(""))
   , m_strTemplateMap(_T(""))
   , m_strCornersMap(_T(""))
   , m_strReferenceMap(_T(""))
   , m_ID1(0)
   , m_ID2(0)
   , m_ID3(0)
   , m_ID4(0)
   , m_strCorrection(_T(""))
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CMapBuilderDlg::DoDataExchange(CDataExchange* pDX)
{
   CDialog::DoDataExchange(pDX);
   DDX_Text(pDX, IDC_EDIT_OUTPUT    , m_strOutputMap);
   DDX_Text(pDX, IDC_EDIT_TEMPLATE  , m_strTemplateMap);
   DDX_Text(pDX, IDC_EDIT_CORNERS   , m_strCornersMap);
   DDX_Text(pDX, IDC_EDIT_REFERENCE , m_strReferenceMap);
   DDX_Text(pDX, IDC_EDIT1, m_ID1);
   DDX_Text(pDX, IDC_EDIT2, m_ID2);
   DDX_Text(pDX, IDC_EDIT3, m_ID3);
   DDX_Text(pDX, IDC_EDIT4, m_ID4);
   DDX_Text(pDX, IDC_EDIT_OUTPUT_CORRECTIONMAP, m_strCorrection);
}

BEGIN_MESSAGE_MAP(CMapBuilderDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
   ON_BN_CLICKED(IDC_RADIO_CORNERS      , &CMapBuilderDlg::OnBnClickedRadioCorners)
   ON_BN_CLICKED(IDC_RADIO_ReferenceMap , &CMapBuilderDlg::OnBnClickedRadioReferenceMap)
   ON_EN_CHANGE(IDC_EDIT_TEMPLATE       , &CMapBuilderDlg::OnEnChangeEditTemplate)
   ON_EN_CHANGE(IDC_EDIT_CORNERS        , &CMapBuilderDlg::OnEnChangeEditCorners)
   ON_EN_CHANGE(IDC_EDIT_REFERENCE      , &CMapBuilderDlg::OnEnChangeEditReference)
   ON_BN_CLICKED(IDC_BUTTON_SHOWLIBRARY , &CMapBuilderDlg::OnBnClickedShowLibrary)
   ON_BN_CLICKED(IDC_BUTTON_BUILDMAP    , &CMapBuilderDlg::OnBnClickedBuildMap)
   ON_BN_CLICKED(IDC_BUTTON_SAVEMAP     , &CMapBuilderDlg::OnBnClickedSaveMap)
   ON_EN_CHANGE(IDC_EDIT1               , &CMapBuilderDlg::OnEnChangeEdit1)
   ON_EN_CHANGE(IDC_EDIT2               , &CMapBuilderDlg::OnEnChangeEdit2)
   ON_EN_CHANGE(IDC_EDIT3               , &CMapBuilderDlg::OnEnChangeEdit3)
   ON_EN_CHANGE(IDC_EDIT4               , &CMapBuilderDlg::OnEnChangeEdit4)
   ON_BN_CLICKED(IDC_BUTTON_LOADFILE1, &CMapBuilderDlg::OnBnClickedButtonLoadfile1)
   ON_BN_CLICKED(IDC_BUTTON_LOADFILE2, &CMapBuilderDlg::OnBnClickedButtonLoadfile2)
   ON_BN_CLICKED(IDC_BUTTON_LOADFILE3, &CMapBuilderDlg::OnBnClickedButtonLoadfile3)
END_MESSAGE_MAP()

// CMapBuilderDlg message handlers

BOOL CMapBuilderDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here

   OnBnClickedRadioCorners() ;

   // debug maps

   // ---------- 1029351
   //m_strCornersMap = "corners: 0 0 0 0; 4 0.0 0.0 125000.0 99800.0; 1 0.0 0.0 3714.7 4722.2 1 1 1; 2 0.0 99800.0 3668.0 104346.7 1 1 1; 3 125000.0 99800.0 128697.9 104308.4 1 1 1; 4 125000.0 0.0 128739.6 4696.7 1 1 1";
   //m_strTemplateMap = "mapext: 0 0 0 0; 4 0.0 0.0 125000.0 99800.0; 1 22427.1 13044.5 25968.6 17694.0 1 1 2; 2 22039.4 83527.5 25819.3 88187.7 1 1 2; 3 107442.0 63837.1 111091.1 68211.8 1 1 2; 4 107663.6 13493.5 111199.0 17828.5 1 1 2";
   //m_strReferenceMap = "mapext: 29351 57 0 1; 4 0.0 0.0 125027.4 99618.1; 1 22251.3 12976.3 25968.6 17694.0 1 1 2; 2 22087.6 83470.0 25819.3 88187.7 1 1 2; 3 107363.5 63511.5 111091.1 68211.8 1 1 2; 4 107481.6 13128.2 111199.0 17828.5 1 1 2";
   
   // ---------- 3040645
   //m_strTemplateMap  = "mapX: 0 0 0 0; 2 0.0 0.0 125100.0 99800.0; 1 121675.0 2399.0 124223.2 5664.2 1 1 2; 2 121388.0 97203.0 124659.7 100401.6 1 1 2 	2 0.999274 0.007630 -0.007630 0.999274 2618.2 4195.3";
   //m_strCornersMap   = "corners: 0 0 0 0; 4 0.0 0.0 125000.0 99800.0; 1 0.0 0.0 2977.5 4271.1 1 1 1; 2 0.0 99800.0 3420.7 103789.2 1 1 1; 3 125000.0 99800.0 128322.2 103218.1 1 1 1; 4 125000.0 0.0 127903.3 3742.9 1 1 1";
   //m_strReferenceMap = "mapext: 3040645 1 0 0; 4 0.0 0.0 124979.7 99516.3; 1 22830.8 12908.1 24779.6 17067.5 1 1 1; 2 22746.7 83354.7 25458.3 87405.4 1 1 1; 3 107967.2 63363.9 110284.1 66582.1 1 1 1; 4 108024.6 13038.0 109793.3 16309.5 1 1 1";

   UpdateData(FALSE) ;

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CMapBuilderDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CMapBuilderDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CMapBuilderDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}
//___________________________________________________________________________//
void CMapBuilderDlg::OnBnClickedRadioCorners()
{
   m_ReferenceType = kTypeCorners ; 
   GetDlgItem( IDC_BUTTON_LOADFILE3 ) -> EnableWindow( FALSE ) ;
   GetDlgItem( IDC_EDIT_REFERENCE )   -> EnableWindow( FALSE ) ;
   GetDlgItem( IDC_STATIC4 ) ->SetWindowText ( "" ) ;
   Update() ;
}
//___________________________________________________________________________//
void CMapBuilderDlg::OnBnClickedRadioReferenceMap()
{
   m_ReferenceType = kTypeReferenceMap ; 
   GetDlgItem( IDC_BUTTON_LOADFILE3 ) -> EnableWindow( TRUE ) ;
   GetDlgItem( IDC_EDIT_REFERENCE )   -> EnableWindow( TRUE ) ;
   GetDlgItem( IDC_STATIC4 ) ->SetWindowText ( "4. Measure the mark position using the REFERENCE MAP and copy the output here" ) ;
   Update() ;
}
//___________________________________________________________________________//
void CMapBuilderDlg::Update()
{
   /*
   if ( m_strTemplateMap.IsEmpty() ) {
      GetDlgItem( IDC_EDIT_CORNERS   )->EnableWindow( FALSE ) ;
      GetDlgItem( IDC_EDIT_REFERENCE )->EnableWindow( FALSE ) ;
   }

   if ( m_strCornersMap.IsEmpty() ) {
      GetDlgItem( IDC_EDIT_REFERENCE )->EnableWindow( FALSE ) ;
   }

   if ( m_ReferenceType = kTypeCorners ) {
      GetDlgItem( IDC_EDIT_REFERENCE )->ShowWindow( FALSE ) ;
      GetDlgItem( IDC_STATIC4        )->ShowWindow( FALSE ) ;
   } else  {
      GetDlgItem( IDC_EDIT_REFERENCE )->ShowWindow( TRUE ) ;
      GetDlgItem( IDC_STATIC4        )->ShowWindow( TRUE ) ;
   }
   */
}
//___________________________________________________________________________//
void CMapBuilderDlg::BuildMap()
{
   UpdateData() ;

   m_strOutputMap = "" ;
   m_strCorrection = "" ;
   UpdateData( FALSE );

   try{

      if (   m_ReferenceType == kTypeCorners &&
           ! m_strTemplateMap.IsEmpty() && 
           ! m_strCornersMap.IsEmpty() 
          )
      {
         TMarkMapBuilder MMB ;

         MMB.SetIDs( m_ID1, m_ID2, m_ID3, m_ID4 ) ;
         MMB.SetCornerMap  ( m_strCornersMap.GetBuffer(0) ) ;
         MMB.SetTemplateMap( m_strTemplateMap.GetBuffer(0)  ) ;

         TMarkMap map = MMB.BuildMap() ;

         m_strOutputMap = map.PrintS().c_str() ;

         UpdateData( FALSE );
      }
      
      if (   m_ReferenceType == kTypeReferenceMap &&
           ! m_strTemplateMap.IsEmpty() && 
           ! m_strCornersMap.IsEmpty() &&
           ! m_strReferenceMap.IsEmpty()
          )
      {
         TMarkMapBuilder MMB ;

         MMB.SetIDs( m_ID1, m_ID2, m_ID3, m_ID4 ) ;
         MMB.SetCornerMap   ( m_strCornersMap.GetBuffer(0)   ) ;
         MMB.SetTemplateMap ( m_strTemplateMap.GetBuffer(0)  ) ;
         MMB.SetReferenceMap( m_strReferenceMap.GetBuffer(0) ) ;

         TMarkMap map = MMB.BuildMap() ;

         m_strOutputMap = map.PrintS().c_str() ;
         
         // Evaluate Correction Map
         TAffine2D aff = CorrectionMap( m_strReferenceMap.GetBuffer(0), map ) ;
         m_strCorrection = aff.PrintTwoLines() ;

         UpdateData( FALSE );
      }
   } catch(const char* msg) {} catch(...) {} 
}
//___________________________________________________________________________//
void CMapBuilderDlg::OnEnChangeEditTemplate()  {  Update(); }
void CMapBuilderDlg::OnEnChangeEditCorners()   {  Update(); }
void CMapBuilderDlg::OnEnChangeEditReference() {  Update(); }
void CMapBuilderDlg::OnEnChangeEdit1()         {  Update(); }
void CMapBuilderDlg::OnEnChangeEdit2()         {  Update(); }
void CMapBuilderDlg::OnEnChangeEdit3()         {  Update(); }
void CMapBuilderDlg::OnEnChangeEdit4()         {  Update(); }
//___________________________________________________________________________//
void CMapBuilderDlg::OnBnClickedShowLibrary()
{  
   CDlgMapLibrary dlg ;
   dlg.DoModal() ;
}
//___________________________________________________________________________//
void CMapBuilderDlg::OnBnClickedBuildMap()
{
   BuildMap() ;
}
//___________________________________________________________________________//
void CMapBuilderDlg::OnBnClickedButtonLoadfile1() { m_strTemplateMap  = FileToString(); UpdateData(FALSE); }
void CMapBuilderDlg::OnBnClickedButtonLoadfile2() { m_strCornersMap   = FileToString(); UpdateData(FALSE); }
void CMapBuilderDlg::OnBnClickedButtonLoadfile3() { m_strReferenceMap = FileToString(); UpdateData(FALSE); }
//___________________________________________________________________________//


const char               kMapDefExt[] = "txt" ;
DWORD                    kMapFlags    = OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT ;
const char BASED_CODE    kMapFilters[] = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*||";


CString CMapBuilderDlg::FileToString()
{
/*
   // read contents of file "bla" into buf, discarding newlines
   string buf, line;

   CFileDialog dlgFile( TRUE, kMapDefExt, "", kMapFlags, kMapFilters );

   INT_PTR nResult = dlgFile.DoModal();
   try {
      std::ifstream in( dlgFile.GetPathName().GetBuffer() );

      while( std::getline(in,line) )
         buf += line;
         in.close() ;
   } catch(...) { throw "error reading file"; }

   return buf.c_str() ;
*/
   // read contents of file "bla" into buf, discarding newlines
   std::string buf, line;

   CFileDialog dlgFile( TRUE, kMapDefExt, "", kMapFlags, kMapFilters );

   INT_PTR nResult = dlgFile.DoModal();
   try {
      std::ifstream in( dlgFile.GetPathName().GetBuffer() );

      while( std::getline(in,line) )
         buf += line;
         in.close() ;
   } catch(...) { throw "error reading file"; }

   return buf.c_str() ;
}
//___________________________________________________________________________//
void CMapBuilderDlg::OnBnClickedSaveMap()
{
   CString fname;
   fname.Format("%07d_%02d_%s",m_ID1,m_ID2, m_strOutputMap.Left( m_strOutputMap.Find(':') ) );
   CFileDialog dlgFile( FALSE, kMapDefExt, fname , kMapFlags, kMapFilters );

   INT_PTR nResult = dlgFile.DoModal();

   std::ofstream file( dlgFile.GetPathName().GetBuffer() ) ;
   file << m_strOutputMap.GetBuffer() << std::endl; 
   file.close() ;

   if ( m_ReferenceType == kTypeReferenceMap ) 
   {
      CString fname2 = dlgFile.GetPathName() ;
      fname2.Insert( fname2.ReverseFind('.') , ".correction" );
      AfxMessageBox( fname2 ) ;

      std::ofstream file2( fname2.GetBuffer() ) ;
      file2 << m_strCorrection.GetBuffer() << std::endl; 
      file2.close() ;
   }
}

