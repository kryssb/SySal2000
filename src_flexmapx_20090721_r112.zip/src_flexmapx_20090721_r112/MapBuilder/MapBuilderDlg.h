// MapBuilderDlg.h : header file
//
#include "DlgMapLibrary.h"

#pragma once

const int kTypeCorners      = 0 ;
const int kTypeReferenceMap = 1 ;

const char temp_frontalxrays[] =  "mapext: 0 0 0 0; 4 0.0 0.0 125000.0 99800.0; 1 22427.1 13044.5 25968.6 17694.0 1 1 2; 2 22039.4 83527.5 25819.3 88187.7 1 1 2; 3 107442.0 63837.1 111091.1 68211.8 1 1 2; 4 107663.6 13493.5 111199.0 17828.5 1 1 2";
const char temp_lateralxrays[] =  "mapX: 0 0 0 0; 2 0.0 0.0 125000.0 99800.0; 1 121675.0 2399.0 125581.5 7490.2 1 1 2; 2 121388.0 97203.0 124765.4 102398.6 1 1 2";
const char temp_optical[]      =  "mapext: 0 0 0 0; 6 0.0 0.0 125000.0 99800.0; 1 9645.0 10256.0 13500.8 14987.8 1 1 2; 2 9457.0 90648.0 13470.3 95391.8 1 1 2; 3 44715.0 90764.0 48725.2 95429.2 1 1 2; 4 114838.0 90930.0 118826.4 95455.0 1 1 2; 5 115069.0 10483.0 118910.8 14996.6 1 1 2; 6 62409.0 10427.0 66261.0 15043.9 1 1 2";


// CMapBuilderDlg dialog
class CMapBuilderDlg : public CDialog
{
// Construction
public:
	CMapBuilderDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	enum { IDD = IDD_MAPBUILDER_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support

   void Update() ;

   // Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()

   void BuildMap() ;
   
   CString FileToString()    ;


public:
   CString m_strOutputMap    ;
   
   // Type of reference map: 0 - Emulsion Corners 1 - Another Map (reference map)
   CString m_strTemplateMap  ;
   CString m_strCornersMap   ;
   CString m_strReferenceMap ;
   CString m_strCorrection   ;

   afx_msg void OnBnClickedRadioCorners();
   afx_msg void OnBnClickedRadioReferenceMap();

   int     m_ReferenceType ;
   afx_msg void OnEnChangeEditTemplate();
   afx_msg void OnEnChangeEditCorners();
   afx_msg void OnEnChangeEditReference();
   afx_msg void OnBnClickedShowLibrary();
   afx_msg void OnBnClickedBuildMap();
   afx_msg void OnBnClickedSaveMap();
   UINT m_ID1;
   UINT m_ID2;
   UINT m_ID3;
   UINT m_ID4;
   afx_msg void OnEnChangeEdit1();
   afx_msg void OnEnChangeEdit2();
   afx_msg void OnEnChangeEdit3();
   afx_msg void OnEnChangeEdit4();
   afx_msg void OnBnClickedButtonLoadfile1();
   afx_msg void OnBnClickedButtonLoadfile2();
   afx_msg void OnBnClickedButtonLoadfile3();
};
